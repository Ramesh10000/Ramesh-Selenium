package pack1;
import com.tinkerpop.blueprints.impls.orient.OrientGraph;
import com.tinkerpop.blueprints.impls.orient.OrientGraphFactory;


public class FirstTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		OrientGraphFactory ogf = new OrientGraphFactory(
	            "plocal:C:/Users/rgunasekaran/Desktop/orientdb-community-2.2.20/orientdb-community-2.2.20/databases/GratefulDeadConcerts", "admin", "admin");
		
		
	    OrientGraph og = ogf.getTx();

	    try {
	        System.out.println("Features = " + og.countVertices());
	    } finally {
	        og.shutdown();
	    }
	}

}
